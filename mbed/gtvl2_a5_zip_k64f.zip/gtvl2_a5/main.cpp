#include "mbed.h"
#include "LM75B.h"
#include "MbedJSONValue.h"
#include "MQTTEthernet.h"
#include "MQTTClient.h"

#define MQTT_URL "http://doughnut.kent.ac.uk"
#define MQTT_PORT 1883
#define MQTT_TOPIC_PUB "meditemp/gtvl2/temperature"
#define MQTT_TOPIC_SUB "meditemp/gtvl2/settings"

Ticker                                  tempTicker;
LM75B                                   tempSensor(D14, D15);
MQTTEthernet                            ipstack = MQTTEthernet();
MQTT::Client<MQTTEthernet, Countdown>   client = MQTT::Client<MQTTEthernet, Countdown>(ipstack);
std::string                             privateId;

std::string                             generateId()
{

    std::string id = "";
    char possible[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    for (int i = 0; i < 10; i++) {
        id += possible[(int) floor(rand() % 100 / 100.0 * sizeof(possible))];
        if (i == 3 || i == 5)
        id += '-';
    }
    return id;
    
}

void                                    sendTemperature()
{
    MQTT::Message message;
 
    char buf[3];
    sprintf(buf, "%s;%d", privateId, (int) tempSensor.read());
    message.qos = MQTT::QOS2;
    message.retained = false;
    message.dup = false;
    message.payload = (void*) buf;
    message.payloadlen = strlen(buf) + 1;
    client.publish(MQTT_TOPIC_PUB, message);
}

void                                    rcv_settings(MQTT::MessageData& md)
{
    MQTT::Message &message = md.message;
    MbedJSONValue json;
    
    parse(json, (char*)message.payload);
    
    int delay = json["settings"]["delay"].get<int>();
    
    tempTicker.detach();
    tempTicker.attach_us(&sendTemperature, delay*1000);
}

int                                     main()
{
    privateId = generateId();
    ipstack.connect(MQTT_URL, MQTT_PORT);
    
    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;       
    data.MQTTVersion = 3;
    client.connect(data);
    client.subscribe(MQTT_TOPIC_SUB, MQTT::QOS2, rcv_settings);
    
    tempTicker.attach(&sendTemperature, 60);
    
    while (true) {
        sleep();
    }    
    
    client.disconnect();
    ipstack.disconnect();
}